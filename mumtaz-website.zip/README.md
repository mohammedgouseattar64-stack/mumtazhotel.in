# Mumtaz Family Restaurant — Website

The complete website source for Mumtaz Family Restaurant, Yellapur.

## How to run it on your computer

You need [Node.js](https://nodejs.org) (version 20 or newer) installed.

1. Open a terminal in this folder.
2. Install the packages:

   ```
   npm install
   ```

3. Start the website:

   ```
   npm run dev
   ```

4. Open the address shown (usually http://localhost:5173) in your browser.

## How to edit your details

Everything you may want to change is in **one file**: `src/data/restaurant.ts`

- Phone number, address and map links
- Opening hours
- Menu dishes, descriptions and prices (currently blank placeholders until you confirm the real menu)
- Photo gallery captions
- Description, rating, services

After editing, save the file and the website updates automatically.

## How to publish it online

```
npm run build
```

This creates a `dist` folder you can upload to any web host that supports
static sites (Netlify, Vercel, Cloudflare Pages, etc.).
