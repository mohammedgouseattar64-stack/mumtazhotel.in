import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";

import { gallery } from "@/data/restaurant";
import { cn } from "@/lib/utils";

const filters = ["All", "Food", "Restaurant", "Ambience"] as const;

export function GalleryGrid() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  const items = useMemo(
    () => (filter === "All" ? gallery : gallery.filter((item) => item.category === filter)),
    [filter],
  );

  const close = useCallback(() => setActiveIndex(null), []);
  const step = useCallback(
    (delta: number) =>
      setActiveIndex((current) =>
        current === null ? null : (current + delta + items.length) % items.length,
      ),
    [items.length],
  );

  useEffect(() => {
    if (activeIndex === null) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") close();
      if (event.key === "ArrowRight") step(1);
      if (event.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [activeIndex, close, step]);

  const active = activeIndex === null ? null : items[activeIndex];

  return (
    <div>
      <div className="no-scrollbar flex gap-2 overflow-x-auto pb-1">
        {filters.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => {
              setFilter(item);
              setActiveIndex(null);
            }}
            aria-pressed={filter === item}
            className={cn(
              "shrink-0 border px-4 py-2 text-sm tracking-wide transition-colors",
              filter === item
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card hover:border-gold",
            )}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="mt-8 columns-1 gap-4 sm:columns-2 lg:columns-3 [&>*]:mb-4">
        {items.map((item, index) => (
          <button
            key={item.src + item.alt}
            type="button"
            onClick={() => setActiveIndex(index)}
            className="zoom-media block w-full border border-border"
            aria-label={`Open image: ${item.alt}`}
          >
            <img
              src={item.src}
              alt={item.alt}
              loading="lazy"
              decoding="async"
              className="w-full object-cover"
            />
          </button>
        ))}
      </div>

      {active ? (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Image viewer"
          className="fixed inset-0 z-[60] flex items-center justify-center bg-charcoal/95 p-4"
          onClick={close}
        >
          <button
            type="button"
            onClick={close}
            aria-label="Close image viewer"
            className="absolute top-4 right-4 inline-flex size-11 items-center justify-center text-charcoal-foreground"
          >
            <X className="size-6" aria-hidden="true" />
          </button>
          <button
            type="button"
            aria-label="Previous image"
            onClick={(event) => {
              event.stopPropagation();
              step(-1);
            }}
            className="absolute left-2 inline-flex size-12 items-center justify-center text-charcoal-foreground sm:left-6"
          >
            <ChevronLeft className="size-7" aria-hidden="true" />
          </button>
          <figure onClick={(event) => event.stopPropagation()} className="max-h-full">
            <img
              src={active.src}
              alt={active.alt}
              className="mx-auto max-h-[75vh] w-auto max-w-full object-contain"
            />
            <figcaption className="mt-4 text-center text-sm text-charcoal-foreground/75">
              {active.alt}
            </figcaption>
          </figure>
          <button
            type="button"
            aria-label="Next image"
            onClick={(event) => {
              event.stopPropagation();
              step(1);
            }}
            className="absolute right-2 inline-flex size-12 items-center justify-center text-charcoal-foreground sm:right-6"
          >
            <ChevronRight className="size-7" aria-hidden="true" />
          </button>
        </div>
      ) : null}
    </div>
  );
}
