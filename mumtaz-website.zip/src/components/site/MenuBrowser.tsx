import { Search } from "lucide-react";
import { useMemo, useState } from "react";

import { MenuCard } from "@/components/site/MenuCard";
import { menuCategories, menuItems } from "@/data/restaurant";
import { cn } from "@/lib/utils";

export function MenuBrowser() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("All");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return menuItems.filter((item) => {
      const inCategory = category === "All" || item.category === category;
      const inQuery =
        q === "" ||
        item.name.toLowerCase().includes(q) ||
        item.description.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q);
      return inCategory && inQuery;
    });
  }, [query, category]);

  const tabs = ["All", ...menuCategories];

  return (
    <div>
      <div className="hairline-gold flex items-center gap-3 border bg-card px-4 py-3">
        <Search className="size-4 shrink-0 text-muted-foreground" aria-hidden="true" />
        <label htmlFor="menu-search" className="sr-only">
          Search dishes
        </label>
        <input
          id="menu-search"
          type="search"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search dishes..."
          className="w-full bg-transparent text-base outline-none placeholder:text-muted-foreground"
        />
      </div>

      <div
        role="tablist"
        aria-label="Menu categories"
        className="no-scrollbar mt-5 flex gap-2 overflow-x-auto pb-1"
      >
        {tabs.map((tab) => (
          <button
            key={tab}
            type="button"
            role="tab"
            aria-selected={category === tab}
            onClick={() => setCategory(tab)}
            className={cn(
              "shrink-0 border px-4 py-2 text-sm tracking-wide transition-colors",
              category === tab
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-foreground hover:border-gold",
            )}
          >
            {tab}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <p className="mt-12 text-center text-muted-foreground">
          No dishes match your search. Try another word or category.
        </p>
      ) : (
        <div
          key={`${category}-${query}`}
          className="mt-8 grid animate-in gap-6 fade-in duration-500 sm:grid-cols-2 lg:grid-cols-3"
        >
          {filtered.map((item) => (
            <MenuCard key={item.id} item={item} />
          ))}
        </div>
      )}
    </div>
  );
}
