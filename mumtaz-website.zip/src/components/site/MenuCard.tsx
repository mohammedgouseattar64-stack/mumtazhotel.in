import type { MenuItem } from "@/data/restaurant";

export function DietBadge({ diet }: { diet: MenuItem["diet"] }) {
  const isVeg = diet === "veg";
  return (
    <span
      className={
        isVeg
          ? "inline-flex items-center gap-1.5 border border-veg/50 px-2 py-0.5 text-[0.65rem] font-semibold tracking-wide uppercase text-veg"
          : "inline-flex items-center gap-1.5 border border-nonveg/50 px-2 py-0.5 text-[0.65rem] font-semibold tracking-wide uppercase text-nonveg"
      }
    >
      <span
        aria-hidden="true"
        className={isVeg ? "size-1.5 rounded-full bg-veg" : "size-1.5 rounded-full bg-nonveg"}
      />
      {isVeg ? "Veg" : "Non-veg"}
    </span>
  );
}

export function MenuCard({ item }: { item: MenuItem }) {
  return (
    <article className="group flex h-full flex-col border border-border bg-card transition-shadow hover:shadow-[var(--shadow-soft)]">
      <div className="zoom-media aspect-[4/3] w-full">
        <img
          src={item.image}
          alt={item.name}
          loading="lazy"
          decoding="async"
          className="h-full w-full object-cover"
        />
      </div>
      <div className="flex flex-1 flex-col gap-2 p-5">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-display text-xl leading-snug">{item.name}</h3>
          <DietBadge diet={item.diet} />
        </div>
        <p className="text-sm leading-relaxed text-muted-foreground">{item.description}</p>
        <p className="mt-auto pt-3 text-sm font-semibold text-primary">
          {item.price === "" ? (
            <span className="font-normal text-muted-foreground">Price on request</span>
          ) : (
            item.price
          )}
        </p>
      </div>
    </article>
  );
}
