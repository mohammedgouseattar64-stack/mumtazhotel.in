import { Link } from "@tanstack/react-router";
import { Bike, MapPin, Phone, UtensilsCrossed } from "lucide-react";

import { restaurant } from "@/data/restaurant";

export function MobileActionBar() {
  const itemClass =
    "flex flex-1 flex-col items-center justify-center gap-1 py-3 text-[0.7rem] font-medium tracking-wide text-charcoal-foreground";

  return (
    <nav
      aria-label="Quick actions"
      className="fixed inset-x-0 bottom-0 z-40 flex border-t border-gold/25 bg-charcoal/95 backdrop-blur-md lg:hidden"
    >
      <Link to="/menu" className={itemClass}>
        <UtensilsCrossed className="size-5 text-gold" aria-hidden="true" />
        Menu
      </Link>
      <a href={restaurant.phoneHref} className={itemClass}>
        <Phone className="size-5 text-gold" aria-hidden="true" />
        Call
      </a>
      <a
        href={restaurant.mapsDirections}
        target="_blank"
        rel="noreferrer"
        className={itemClass}
      >
        <MapPin className="size-5 text-gold" aria-hidden="true" />
        Directions
      </a>
      <a href={restaurant.phoneHref} className={itemClass}>
        <Bike className="size-5 text-gold" aria-hidden="true" />
        Order
      </a>
    </nav>
  );
}
