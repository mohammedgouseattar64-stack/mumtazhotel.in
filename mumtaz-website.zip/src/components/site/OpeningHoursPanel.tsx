import { useEffect, useState } from "react";

import { hoursLabel, isOpenAt, openingHours } from "@/data/restaurant";
import { cn } from "@/lib/utils";

export function OpeningHoursPanel({ className }: { className?: string }) {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const timer = window.setInterval(() => setNow(new Date()), 60_000);
    return () => window.clearInterval(timer);
  }, []);

  const todayIndex = now?.getDay();
  const open = now ? isOpenAt(now) : null;

  return (
    <div className={cn("hairline-gold border bg-card p-6 sm:p-8", className)}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h3 className="font-display text-2xl">Opening Hours</h3>
        {open === null ? null : (
          <span
            className={cn(
              "inline-flex items-center gap-2 border px-3 py-1 text-xs font-semibold tracking-wide uppercase",
              open ? "border-veg/40 text-veg" : "border-nonveg/40 text-nonveg",
            )}
          >
            <span
              aria-hidden="true"
              className={cn("size-2 rounded-full", open ? "bg-veg" : "bg-nonveg")}
            />
            {open ? "Open Now" : "Closed Now"}
          </span>
        )}
      </div>

      <ul className="mt-6 divide-y divide-border">
        {openingHours.map((entry, index) => {
          const isToday = index === todayIndex;
          return (
            <li
              key={entry.day}
              className={cn(
                "flex flex-wrap items-baseline justify-between gap-x-6 gap-y-1 py-3 text-sm",
                isToday && "font-semibold text-primary",
              )}
            >
              <span className="flex items-center gap-2">
                {entry.day}
                {isToday ? <span className="eyebrow text-[0.6rem]">Today</span> : null}
              </span>
              <span className={cn("text-right", !isToday && "text-muted-foreground")}>
                {hoursLabel(entry)}
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
