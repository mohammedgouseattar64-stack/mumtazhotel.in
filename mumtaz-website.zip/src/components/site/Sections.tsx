import { Link } from "@tanstack/react-router";
import { Bike, Copy, MapPin, Phone, Star, UtensilsCrossed } from "lucide-react";
import { useState, type ReactNode } from "react";

import { Reveal } from "@/components/site/Reveal";
import { images, restaurant } from "@/data/restaurant";
import { cn } from "@/lib/utils";

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = "left",
  as: Tag = "h2",
}: {
  eyebrow?: string;
  title: ReactNode;
  description?: string;
  align?: "left" | "center";
  as?: "h1" | "h2";
}) {
  return (
    <div className={cn("max-w-2xl", align === "center" && "mx-auto text-center")}>
      {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
      <Tag className="mt-3 text-3xl leading-tight sm:text-4xl lg:text-[2.75rem]">{title}</Tag>
      {description ? (
        <p className="mt-4 text-base leading-relaxed text-muted-foreground">{description}</p>
      ) : null}
    </div>
  );
}

export function QuickActions() {
  const actions = [
    {
      label: "View Menu",
      hint: "Browse dishes by category",
      icon: UtensilsCrossed,
      to: "/menu" as const,
    },
    {
      label: "Call Us",
      hint: restaurant.phoneDisplay,
      icon: Phone,
      href: restaurant.phoneHref,
    },
    {
      label: "Get Directions",
      hint: "NH67, Yellapur",
      icon: MapPin,
      href: restaurant.mapsDirections,
      external: true,
    },
    {
      label: "Order Food",
      hint: "Takeaway & delivery — call to order",
      icon: Bike,
      href: restaurant.phoneHref,
    },
  ];

  return (
    <section aria-label="Quick actions" className="border-y border-border bg-secondary">
      <div className="mx-auto grid max-w-7xl gap-px sm:grid-cols-2 lg:grid-cols-4">
        {actions.map((action) => {
          const Icon = action.icon;
          const inner = (
            <>
              <Icon className="size-6 text-gold" aria-hidden="true" />
              <span className="mt-4 font-display text-xl">{action.label}</span>
              <span className="mt-1 text-sm text-muted-foreground">{action.hint}</span>
            </>
          );
          const classes =
            "flex min-h-[9.5rem] flex-col justify-center border-b border-border bg-background px-6 py-8 transition-colors hover:bg-secondary sm:border-r";
          return action.to ? (
            <Link key={action.label} to={action.to} className={classes}>
              {inner}
            </Link>
          ) : (
            <a
              key={action.label}
              href={action.href}
              {...(action.external ? { target: "_blank", rel: "noreferrer" } : {})}
              className={classes}
            >
              {inner}
            </a>
          );
        })}
      </div>
    </section>
  );
}

export function RatingPanel() {
  const stars = [1, 2, 3, 4, 5];
  const distribution = restaurant.rating / 5;

  return (
    <div className="hairline-gold border bg-card p-8 text-center sm:p-10">
      <p className="font-display text-6xl text-primary">{restaurant.rating.toFixed(1)}</p>
      <p className="mt-2 text-sm text-muted-foreground">out of 5</p>
      <div className="mt-4 flex items-center justify-center gap-1" aria-hidden="true">
        {stars.map((star) => (
          <Star
            key={star}
            className={cn(
              "size-5",
              star <= Math.round(restaurant.rating) ? "fill-gold text-gold" : "text-border",
            )}
          />
        ))}
      </div>
      <p className="sr-only">{`Rated ${restaurant.rating} out of 5 from ${restaurant.reviewCount} reviews`}</p>
      <p className="mt-4 text-sm font-semibold tracking-wide">
        {restaurant.reviewCount.toLocaleString("en-IN")} Reviews
      </p>
      <div className="mt-6 h-1.5 w-full bg-secondary">
        <div className="h-full bg-gold" style={{ width: `${distribution * 100}%` }} />
      </div>
      <a
        href={restaurant.reviewsUrl}
        target="_blank"
        rel="noreferrer"
        className="mt-8 inline-flex bg-primary px-6 py-3 text-sm font-semibold tracking-wide text-primary-foreground transition-opacity hover:opacity-90"
      >
        See Reviews
      </a>
    </div>
  );
}

export function LocationSection() {
  const [copied, setCopied] = useState(false);

  const copyAddress = async () => {
    try {
      await navigator.clipboard.writeText(restaurant.address);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section id="location" className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-28">
      <Reveal>
        <SectionHeading
          eyebrow="Location"
          title="Find Us in Yellapur"
          description={`${restaurant.fullName} is on ${restaurant.addressShort}. Dine in, collect a takeaway or call to order.`}
        />
      </Reveal>

      <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.15fr] lg:items-start">
        <Reveal className="hairline-gold border bg-card p-8">
          <h3 className="font-display text-2xl">{restaurant.fullName}</h3>
          <address className="mt-4 text-base leading-relaxed text-muted-foreground not-italic">
            {restaurant.address}
          </address>
          <button
            type="button"
            onClick={copyAddress}
            className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary hover:text-gold"
          >
            <Copy className="size-4" aria-hidden="true" />
            {copied ? "Address copied" : "Copy address"}
          </button>
          <p className="mt-6 text-sm text-muted-foreground">{restaurant.priceRange}</p>
          <p className="mt-1 text-sm text-muted-foreground">{restaurant.services.join(" • ")}</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href={restaurant.mapsDirections}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              <MapPin className="size-4" aria-hidden="true" />
              Get Directions
            </a>
            <a
              href={restaurant.phoneHref}
              className="hairline-gold inline-flex items-center justify-center gap-2 border px-6 py-3 text-sm font-semibold transition-colors hover:bg-secondary"
            >
              <Phone className="size-4" aria-hidden="true" />
              Call Restaurant
            </a>
          </div>
        </Reveal>

        <Reveal className="h-[22rem] border border-border lg:h-[28rem]">
          <iframe
            title={`Map showing ${restaurant.fullName} in Yellapur`}
            src={restaurant.mapsEmbed}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            className="h-full w-full"
          />
        </Reveal>
      </div>
    </section>
  );
}

export function FinalCta() {
  return (
    <section className="relative isolate overflow-hidden">
      <img
        src={images.kebabPlatter}
        alt="Kebab platter served at Mumtaz Family Restaurant in Yellapur"
        loading="lazy"
        decoding="async"
        className="absolute inset-0 -z-10 h-full w-full object-cover object-[center_32%]"
      />
      <div className="absolute inset-0 -z-10 bg-charcoal/80" />
      <div className="mx-auto max-w-3xl px-4 py-24 text-center text-charcoal-foreground sm:px-6 lg:py-32">
        <h2 className="text-3xl leading-tight sm:text-4xl lg:text-5xl">Good Food Is Better Shared.</h2>
        <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-charcoal-foreground/80">
          Visit Mumtaz Family Restaurant in Yellapur and enjoy a meal with the people who matter.
        </p>
        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row">
          <Link
            to="/menu"
            className="w-full bg-gold px-7 py-3.5 text-sm font-semibold tracking-wide text-charcoal transition-opacity hover:opacity-90 sm:w-auto"
          >
            View Menu
          </Link>
          <a
            href={restaurant.phoneHref}
            className="hairline-gold w-full border px-7 py-3.5 text-sm font-semibold tracking-wide transition-colors hover:bg-charcoal-foreground/10 sm:w-auto"
          >
            Call Now
          </a>
          <a
            href={restaurant.mapsDirections}
            target="_blank"
            rel="noreferrer"
            className="hairline-gold w-full border px-7 py-3.5 text-sm font-semibold tracking-wide transition-colors hover:bg-charcoal-foreground/10 sm:w-auto"
          >
            Get Directions
          </a>
        </div>
      </div>
    </section>
  );
}
