import { Link } from "@tanstack/react-router";

import { hoursLabel, navLinks, openingHours, restaurant } from "@/data/restaurant";

export function SiteFooter() {
  return (
    <footer className="bg-charcoal text-charcoal-foreground">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:py-20">
        <div className="grid gap-12 lg:grid-cols-4">
          <div>
            <p className="font-display text-3xl">{restaurant.name}</p>
            <p className="mt-1 text-lg text-gold-soft">{restaurant.nameKannada}</p>
            <p className="mt-4 text-sm text-charcoal-foreground/70">
              {restaurant.category} • {restaurant.city}
            </p>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-charcoal-foreground/70">
              {restaurant.services.join(" • ")}
            </p>
            {restaurant.social.length > 0 ? (
              <ul className="mt-5 flex flex-wrap gap-4 text-sm">
                {restaurant.social.map((item) => (
                  <li key={item.url}>
                    <a href={item.url} className="text-gold hover:underline">
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>

          <nav aria-label="Footer">
            <h2 className="eyebrow">Quick Links</h2>
            <ul className="mt-5 space-y-3 text-sm">
              {navLinks.map((link) => (
                <li key={link.to}>
                  <Link
                    to={link.to}
                    className="text-charcoal-foreground/80 transition-colors hover:text-gold"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h2 className="eyebrow">Contact</h2>
            <ul className="mt-5 space-y-3 text-sm text-charcoal-foreground/80">
              <li>
                <a href={restaurant.phoneHref} className="hover:text-gold">
                  {restaurant.phoneDisplay}
                </a>
              </li>
              <li className="leading-relaxed">{restaurant.addressShort}</li>
              <li>
                <a
                  href={restaurant.mapsDirections}
                  target="_blank"
                  rel="noreferrer"
                  className="text-gold hover:underline"
                >
                  Get Directions
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h2 className="eyebrow">Opening Hours</h2>
            <ul className="mt-5 space-y-2 text-sm text-charcoal-foreground/80">
              {openingHours.map((entry) => (
                <li key={entry.day} className="flex flex-wrap justify-between gap-x-4 gap-y-1">
                  <span>{entry.day}</span>
                  <span className="text-charcoal-foreground/60">{hoursLabel(entry)}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 border-t border-charcoal-foreground/10 pt-6 text-xs text-charcoal-foreground/55">
          © 2026 {restaurant.fullName}. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
