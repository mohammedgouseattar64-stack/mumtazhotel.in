import { Link } from "@tanstack/react-router";
import { Menu, Phone, X } from "lucide-react";
import { useEffect, useState } from "react";

import { navLinks, restaurant } from "@/data/restaurant";
import { cn } from "@/lib/utils";

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-charcoal/95 shadow-[var(--shadow-soft)] backdrop-blur-md"
          : "bg-charcoal/45 backdrop-blur-sm",
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3 sm:px-6 lg:py-4">
        <Link
          to="/"
          className="flex min-w-0 items-baseline gap-2 text-charcoal-foreground"
          aria-label={`${restaurant.fullName} home`}
        >
          <span className="font-display text-2xl leading-none tracking-wide lg:text-[1.75rem]">
            {restaurant.name}
          </span>
          <span className="truncate text-sm text-gold-soft">{restaurant.nameKannada}</span>
        </Link>

        <nav aria-label="Main" className="mx-auto hidden items-center gap-7 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              activeOptions={{ exact: link.to === "/" }}
              className="text-sm tracking-wide text-charcoal-foreground/80 transition-colors hover:text-gold data-[status=active]:text-gold"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto hidden items-center gap-3 lg:flex">
          <Link
            to="/menu"
            className="hairline-gold border px-4 py-2 text-sm font-medium tracking-wide text-charcoal-foreground transition-colors hover:bg-gold hover:text-charcoal"
          >
            View Menu
          </Link>
          <a
            href={restaurant.phoneHref}
            className="inline-flex items-center gap-2 bg-primary px-4 py-2 text-sm font-semibold tracking-wide text-primary-foreground transition-opacity hover:opacity-90"
          >
            <Phone className="size-4" aria-hidden="true" />
            Call Now
          </a>
        </div>

        <button
          type="button"
          onClick={() => setOpen(true)}
          aria-expanded={open}
          aria-label="Open menu"
          className="ml-auto inline-flex size-11 items-center justify-center text-charcoal-foreground lg:hidden"
        >
          <Menu className="size-6" aria-hidden="true" />
        </button>
      </div>

      {open ? (
        <div className="fixed inset-0 top-0 z-50 flex flex-col bg-charcoal text-charcoal-foreground lg:hidden">
          <div className="flex items-center justify-between px-4 py-3">
            <span className="font-display text-2xl">{restaurant.name}</span>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close menu"
              className="inline-flex size-11 items-center justify-center"
            >
              <X className="size-6" />
            </button>
          </div>
          <nav aria-label="Mobile" className="flex flex-col px-4 pt-4">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                onClick={() => setOpen(false)}
                activeOptions={{ exact: link.to === "/" }}
                className="border-b border-charcoal-foreground/10 py-4 font-display text-2xl data-[status=active]:text-gold"
              >
                {link.label}
              </Link>
            ))}
          </nav>
          <div className="mt-auto grid grid-cols-2 gap-3 p-4">
            <Link
              to="/menu"
              onClick={() => setOpen(false)}
              className="hairline-gold border px-4 py-3 text-center text-sm font-medium"
            >
              View Menu
            </Link>
            <a
              href={restaurant.phoneHref}
              className="bg-primary px-4 py-3 text-center text-sm font-semibold text-primary-foreground"
            >
              Call Now
            </a>
          </div>
        </div>
      ) : null}
    </header>
  );
}
