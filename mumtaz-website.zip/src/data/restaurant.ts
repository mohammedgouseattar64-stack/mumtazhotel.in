/**
 * Central restaurant data for Mumtaz Family Restaurant.
 * Owner-editable: phone, address, hours, menu items, prices, gallery, description.
 * Nothing here should be duplicated inside components.
 */

import biryani from "@/assets/biryani.png";
import chickenDry from "@/assets/chicken-dry.png";
import chickenFry from "@/assets/chicken-fry.png";
import curry from "@/assets/curry.png";
import dalFry from "@/assets/dal-fry.png";
import halwa from "@/assets/halwa.png";
import kebabPlatter from "@/assets/kebab-platter.png";
import paratha from "@/assets/paratha.png";
import pulaoSoup from "@/assets/pulao-soup.png";
import thali from "@/assets/thali.png";
import biryaniPot from "@/assets/biryani-pot.png";
import chickenBiryani from "@/assets/chicken-biryani.png";
import chickenLollipop from "@/assets/chicken-lollipop.png";
import chilliChicken from "@/assets/chilli-chicken.png";
import eggBiryani from "@/assets/egg-biryani.png";
import fishFry from "@/assets/fish-fry.png";
import friedChicken from "@/assets/fried-chicken.png";
import pepperChicken from "@/assets/pepper-chicken.png";
import tandooriPlatter from "@/assets/tandoori-platter.png";

export const images = {
  biryaniPot: biryaniPot,
  chickenBiryani: chickenBiryani,
  chickenLollipop: chickenLollipop,
  chilliChicken: chilliChicken,
  eggBiryani: eggBiryani,
  fishFry: fishFry,
  friedChicken: friedChicken,
  pepperChicken: pepperChicken,
  tandooriPlatter: tandooriPlatter,
  biryani: biryani,
  chickenDry: chickenDry,
  chickenFry: chickenFry,
  curry: curry,
  dalFry: dalFry,
  halwa: halwa,
  kebabPlatter: kebabPlatter,
  paratha: paratha,
  pulaoSoup: pulaoSoup,
  thali: thali,
};

export const restaurant = {
  name: "Mumtaz",
  nameKannada: "ಮುಮ್ತಾಜ",
  fullName: "Mumtaz Family Restaurant",
  category: "Family Restaurant",
  city: "Yellapur",
  address: "NH67, Yellapur, Karnataka 581359, India",
  addressShort: "NH67, Yellapur, Karnataka 581359",
  phoneDisplay: "099020 40380",
  phoneHref: "tel:09902040380",
  priceRange: "₹200–₹400 per person",
  rating: 3.9,
  reviewCount: 2524,
  services: ["Dine-in", "Takeaway", "Delivery"],
  cuisines: ["Seafood", "Kebabs", "Traditional Indian food", "Chinese food", "Family meals"],
  description:
    "Mumtaz Family Restaurant is a family restaurant in Yellapur, Karnataka, serving seafood, kebabs, traditional Indian dishes and Chinese food. Dine in with family, pick up a takeaway, or have your meal delivered.",
  mapsDirections:
    "https://www.google.com/maps/dir/?api=1&destination=Mumtaz+Family+Restaurant+NH67+Yellapur+Karnataka+581359",
  mapsPlace:
    "https://www.google.com/maps/search/?api=1&query=Mumtaz+Family+Restaurant+NH67+Yellapur+Karnataka+581359",
  mapsEmbed:
    "https://www.google.com/maps?q=Mumtaz%20Family%20Restaurant%20NH67%20Yellapur%20Karnataka%20581359&output=embed",
  reviewsUrl:
    "https://www.google.com/maps/search/?api=1&query=Mumtaz+Family+Restaurant+Yellapur+reviews",
  /** Add real profile URLs here to make social links appear in the footer. */
  social: [] as Array<{ label: string; url: string }>,
};

/** Opening hours. Times are 24h minutes-from-midnight ranges. */
export type HourRange = { open: string; close: string };
export type DayHours = { day: string; ranges: HourRange[]; allDay?: boolean };

/** Index 0 = Sunday, matching Date.getDay(). */
export const openingHours: DayHours[] = [
  { day: "Sunday", ranges: [{ open: "00:00", close: "23:59" }], allDay: true },
  {
    day: "Monday",
    ranges: [
      { open: "11:30", close: "16:00" },
      { open: "18:30", close: "23:29" },
    ],
  },
  {
    day: "Tuesday",
    ranges: [
      { open: "11:30", close: "16:00" },
      { open: "18:30", close: "23:29" },
    ],
  },
  {
    day: "Wednesday",
    ranges: [
      { open: "11:30", close: "16:00" },
      { open: "18:30", close: "23:29" },
    ],
  },
  {
    day: "Thursday",
    ranges: [
      { open: "11:30", close: "16:00" },
      { open: "18:30", close: "23:29" },
    ],
  },
  {
    day: "Friday",
    ranges: [
      { open: "11:30", close: "16:00" },
      { open: "18:30", close: "23:29" },
    ],
  },
  {
    day: "Saturday",
    ranges: [
      { open: "11:30", close: "16:00" },
      { open: "18:30", close: "23:29" },
    ],
  },
];

export function formatTime(value: string): string {
  const parts = value.split(":");
  const h = Number(parts[0] ?? 0);
  const m = Number(parts[1] ?? 0);
  const suffix = h >= 12 ? "PM" : "AM";
  const hour12 = h % 12 === 0 ? 12 : h % 12;
  return `${hour12}:${String(m).padStart(2, "0")} ${suffix}`;
}

export function hoursLabel(entry: DayHours): string {
  if (entry.allDay) return "Open 24 Hours";
  return entry.ranges.map((r) => `${formatTime(r.open)}–${formatTime(r.close)}`).join(", ");
}

export function isOpenAt(date: Date): boolean {
  const entry = openingHours[date.getDay()];
  if (!entry) return false;
  if (entry.allDay) return true;
  const minutes = date.getHours() * 60 + date.getMinutes();
  const toMin = (v: string) => {
    const p = v.split(":");
    return Number(p[0] ?? 0) * 60 + Number(p[1] ?? 0);
  };
  return entry.ranges.some((r) => minutes >= toMin(r.open) && minutes <= toMin(r.close));
}

export const cuisineCategories = [
  {
    title: "Seafood",
    description: "Fresh and flavourful seafood dishes.",
    image: images.thali,
    alt: "Seafood thali with rice, roti and curry at Mumtaz Family Restaurant, Yellapur",
  },
  {
    title: "Kebabs",
    description: "Succulent, smoky and delicious kebab selections.",
    image: images.kebabPlatter,
    alt: "Grilled kebab platter with onion salad at Mumtaz, Yellapur",
  },
  {
    title: "Indian Classics",
    description: "Traditional favourites for comforting family meals.",
    image: images.dalFry,
    alt: "Rich Indian dal served in a ceramic dish at Mumtaz, Yellapur",
  },
  {
    title: "Chinese",
    description: "Popular Chinese-inspired dishes.",
    image: images.chickenDry,
    alt: "Dry chilli chicken with green chillies served at Mumtaz, Yellapur",
  },
];

export type MenuCategory =
  | "Starters"
  | "Kebabs"
  | "Seafood"
  | "Chicken"
  | "Mutton"
  | "Rice & Biryani"
  | "Indian Main Course"
  | "Chinese"
  | "Vegetarian"
  | "Beverages"
  | "Desserts";

export const menuCategories: MenuCategory[] = [
  "Starters",
  "Kebabs",
  "Seafood",
  "Chicken",
  "Mutton",
  "Rice & Biryani",
  "Indian Main Course",
  "Chinese",
  "Vegetarian",
  "Beverages",
  "Desserts",
];

export type MenuItem = {
  id: string;
  name: string;
  category: MenuCategory;
  description: string;
  /** Leave price empty until the restaurant confirms it. */
  price: string;
  diet: "veg" | "nonveg";
  image: string;
  featured?: boolean;
};

/**
 * PLACEHOLDER MENU — dish names, descriptions and prices are editable placeholders,
 * not confirmed Mumtaz menu data. Replace each entry with the real menu.
 */
export const menuItems: MenuItem[] = [
  {
    id: "starter-1",
    name: "Starter Item 1",
    category: "Starters",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.chickenLollipop,
    featured: true,
  },
  {
    id: "starter-2",
    name: "Starter Item 2",
    category: "Starters",
    description: "Add the dish description here.",
    price: "",
    diet: "veg",
    image: images.dalFry,
  },
  {
    id: "kebab-1",
    name: "Kebab Item 1",
    category: "Kebabs",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.kebabPlatter,
    featured: true,
  },
  {
    id: "kebab-2",
    name: "Kebab Item 2",
    category: "Kebabs",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.tandooriPlatter,
  },
  {
    id: "seafood-1",
    name: "Seafood Item 1",
    category: "Seafood",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.thali,
    featured: true,
  },
  {
    id: "seafood-2",
    name: "Seafood Item 2",
    category: "Seafood",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.fishFry,
  },
  {
    id: "chicken-1",
    name: "Chicken Item 1",
    category: "Chicken",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.pepperChicken,
  },
  {
    id: "chicken-2",
    name: "Chicken Item 2",
    category: "Chicken",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.friedChicken,
  },
  {
    id: "mutton-1",
    name: "Mutton Item 1",
    category: "Mutton",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.curry,
  },
  {
    id: "rice-1",
    name: "Biryani Item 1",
    category: "Rice & Biryani",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.chickenBiryani,
    featured: true,
  },
  {
    id: "rice-2",
    name: "Rice Item 2",
    category: "Rice & Biryani",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.eggBiryani,
  },
  {
    id: "indian-1",
    name: "Indian Main Course Item 1",
    category: "Indian Main Course",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.curry,
  },
  {
    id: "indian-2",
    name: "Indian Main Course Item 2",
    category: "Indian Main Course",
    description: "Add the dish description here.",
    price: "",
    diet: "veg",
    image: images.paratha,
  },
  {
    id: "chinese-1",
    name: "Chinese Item 1",
    category: "Chinese",
    description: "Add the dish description here.",
    price: "",
    diet: "nonveg",
    image: images.chilliChicken,
  },
  {
    id: "chinese-2",
    name: "Chinese Item 2",
    category: "Chinese",
    description: "Add the dish description here.",
    price: "",
    diet: "veg",
    image: images.pulaoSoup,
  },
  {
    id: "veg-1",
    name: "Vegetarian Item 1",
    category: "Vegetarian",
    description: "Add the dish description here.",
    price: "",
    diet: "veg",
    image: images.dalFry,
  },
  {
    id: "veg-2",
    name: "Vegetarian Item 2",
    category: "Vegetarian",
    description: "Add the dish description here.",
    price: "",
    diet: "veg",
    image: images.thali,
  },
  {
    id: "beverage-1",
    name: "Beverage Item 1",
    category: "Beverages",
    description: "Add the drink description here.",
    price: "",
    diet: "veg",
    image: images.pulaoSoup,
  },
  {
    id: "dessert-1",
    name: "Dessert Item 1",
    category: "Desserts",
    description: "Add the dessert description here.",
    price: "",
    diet: "veg",
    image: images.halwa,
    featured: true,
  },
];

export type GalleryCategory = "Food" | "Restaurant" | "Ambience";

export const gallery: Array<{
  src: string;
  alt: string;
  category: GalleryCategory;
}> = [
  {
    src: images.kebabPlatter,
    alt: "Large kebab platter with onion salad at Mumtaz Family Restaurant, Yellapur",
    category: "Food",
  },
  {
    src: images.biryani,
    alt: "Biryani served with raita and curry at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.thali,
    alt: "Indian meal thali with rice, roti, curry and sides at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.curry,
    alt: "Freshly cooked curry on a serving tray at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.chickenFry,
    alt: "Dry chicken fry plated with salad on a restaurant table at Mumtaz",
    category: "Restaurant",
  },
  {
    src: images.paratha,
    alt: "Flaky paratha served with curry on a plate at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.dalFry,
    alt: "Dal served in an oval dish at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.pulaoSoup,
    alt: "Pulao served with soup at Mumtaz Family Restaurant, Yellapur",
    category: "Restaurant",
  },
  {
    src: images.halwa,
    alt: "Freshly prepared halwa packed in the Mumtaz kitchen, Yellapur",
    category: "Ambience",
  },
  {
    src: images.chickenDry,
    alt: "Chilli chicken plated on a square dish at Mumtaz, Yellapur",
    category: "Ambience",
  },
  {
    src: images.eggBiryani,
    alt: "Egg biryani with raita and curry at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.chickenBiryani,
    alt: "Chicken biryani served with onion at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.biryaniPot,
    alt: "Biryani served in a pot with curry and chutney at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.chickenLollipop,
    alt: "Chicken lollipop with cabbage salad at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.friedChicken,
    alt: "Crispy fried chicken pieces at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.fishFry,
    alt: "Crispy fish fry at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.chilliChicken,
    alt: "Chilli chicken with peppers and onions at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.pepperChicken,
    alt: "Pepper chicken garnished with salad at Mumtaz, Yellapur",
    category: "Food",
  },
  {
    src: images.tandooriPlatter,
    alt: "Grilled tandoori platter with fresh salad at Mumtaz, Yellapur",
    category: "Food",
  },
];

export const navLinks = [
  { label: "Home", to: "/" as const },
  { label: "About", to: "/about" as const },
  { label: "Menu", to: "/menu" as const },
  { label: "Gallery", to: "/gallery" as const },
  { label: "Reviews", to: "/reviews" as const },
  { label: "Contact", to: "/contact" as const },
];
