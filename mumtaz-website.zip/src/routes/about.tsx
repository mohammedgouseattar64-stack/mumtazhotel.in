import { Link, createFileRoute } from "@tanstack/react-router";

import { OpeningHoursPanel } from "@/components/site/OpeningHoursPanel";
import { Reveal } from "@/components/site/Reveal";
import { FinalCta, SectionHeading } from "@/components/site/Sections";
import { cuisineCategories, images, restaurant } from "@/data/restaurant";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Mumtaz Family Restaurant, Yellapur" },
      {
        name: "description",
        content:
          "Mumtaz is a family restaurant on NH67 in Yellapur, Karnataka serving seafood, kebabs, traditional Indian dishes and Chinese food, with dine-in, takeaway and delivery.",
      },
      { property: "og:title", content: "About Mumtaz Family Restaurant, Yellapur" },
      {
        property: "og:description",
        content:
          "A family restaurant in Yellapur serving seafood, kebabs, Indian classics and Chinese food.",
      },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <>
      <section className="border-b border-border bg-secondary pt-32 pb-16 lg:pt-40 lg:pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            as="h1"
            eyebrow="About Mumtaz"
            title="A Place for Good Food & Good Company"
            description={restaurant.description}
          />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center lg:gap-16">
          <Reveal className="zoom-media border border-border">
            <img
              src={images.biryani}
              alt="Biryani served with raita and curry at Mumtaz Family Restaurant, Yellapur"
              loading="lazy"
              decoding="async"
              className="aspect-[4/3] w-full object-cover"
            />
          </Reveal>
          <Reveal delay={100}>
            <h2 className="text-3xl leading-tight sm:text-4xl">Family dining on NH67</h2>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              Mumtaz Family Restaurant sits on NH67 in Yellapur, Karnataka. The kitchen covers
              seafood, kebabs, traditional Indian dishes and Chinese food, so a whole family can
              order very different plates and still eat together.
            </p>
            <p className="mt-4 text-base leading-relaxed text-muted-foreground">
              You can dine in, collect a takeaway, or have your order delivered. A typical meal
              works out to {restaurant.priceRange.toLowerCase()}.
            </p>
            <dl className="mt-10 grid gap-x-8 gap-y-6 sm:grid-cols-2">
              {[
                { term: "Category", detail: restaurant.category },
                { term: "Location", detail: restaurant.addressShort },
                { term: "Services", detail: restaurant.services.join(" • ") },
                { term: "Price", detail: restaurant.priceRange },
              ].map((row) => (
                <div key={row.term} className="border-l-2 border-gold pl-4">
                  <dt className="eyebrow">{row.term}</dt>
                  <dd className="mt-1.5 text-base">{row.detail}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </section>

      <section className="bg-secondary py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Reveal>
            <SectionHeading
              eyebrow="What We Cook"
              title="Flavours for Every Table"
              description="Four kitchens' worth of variety on one menu."
            />
          </Reveal>
          <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {cuisineCategories.map((cuisine, index) => (
              <Reveal key={cuisine.title} delay={index * 70} className="border border-border bg-card">
                <div className="zoom-media aspect-[4/3] w-full">
                  <img
                    src={cuisine.image}
                    alt={cuisine.alt}
                    loading="lazy"
                    decoding="async"
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="p-5">
                  <h3 className="font-display text-xl">{cuisine.title}</h3>
                  <p className="mt-1.5 text-sm text-muted-foreground">{cuisine.description}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:items-center lg:py-28">
        <Reveal>
          <OpeningHoursPanel />
        </Reveal>
        <Reveal delay={100}>
          <h2 className="text-3xl leading-tight sm:text-4xl">Planning a visit?</h2>
          <p className="mt-5 text-base leading-relaxed text-muted-foreground">
            Browse the menu before you arrive, or call {restaurant.phoneDisplay} for takeaway and
            delivery.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              to="/menu"
              className="bg-primary px-6 py-3 text-center text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              View Menu
            </Link>
            <a
              href={restaurant.phoneHref}
              className="hairline-gold border px-6 py-3 text-center text-sm font-semibold transition-colors hover:bg-secondary"
            >
              Call Now
            </a>
          </div>
        </Reveal>
      </section>

      <FinalCta />
    </>
  );
}
