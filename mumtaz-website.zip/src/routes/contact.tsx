import { createFileRoute } from "@tanstack/react-router";

import { OpeningHoursPanel } from "@/components/site/OpeningHoursPanel";
import { Reveal } from "@/components/site/Reveal";
import { FinalCta, LocationSection, SectionHeading } from "@/components/site/Sections";
import { restaurant } from "@/data/restaurant";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Directions | Mumtaz Family Restaurant, Yellapur" },
      {
        name: "description",
        content:
          "Call Mumtaz Family Restaurant on 099020 40380 or find us on NH67, Yellapur, Karnataka 581359. Opening hours, directions and delivery details.",
      },
      { property: "og:title", content: "Contact & Directions | Mumtaz Family Restaurant" },
      {
        property: "og:description",
        content: "Phone, address, opening hours and directions for Mumtaz in Yellapur, Karnataka.",
      },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <>
      <section className="border-b border-border bg-secondary pt-32 pb-16 lg:pt-40 lg:pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            as="h1"
            eyebrow="Contact"
            title="Talk to Mumtaz"
            description={`Call ${restaurant.phoneDisplay} for dine-in enquiries, takeaway or delivery.`}
          />
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:py-20">
        <Reveal className="hairline-gold border bg-card p-8">
          <h2 className="font-display text-2xl">Phone</h2>
          <a
            href={restaurant.phoneHref}
            className="mt-3 inline-block text-2xl font-semibold text-primary hover:text-gold"
          >
            {restaurant.phoneDisplay}
          </a>
          <h3 className="mt-8 font-display text-xl">Address</h3>
          <address className="mt-2 text-base leading-relaxed text-muted-foreground not-italic">
            {restaurant.address}
          </address>
          <h3 className="mt-8 font-display text-xl">Services</h3>
          <p className="mt-2 text-base text-muted-foreground">{restaurant.services.join(" • ")}</p>
          <h3 className="mt-8 font-display text-xl">Typical Spend</h3>
          <p className="mt-2 text-base text-muted-foreground">{restaurant.priceRange}</p>
        </Reveal>
        <Reveal delay={100}>
          <OpeningHoursPanel />
        </Reveal>
      </section>

      <LocationSection />
      <FinalCta />
    </>
  );
}
