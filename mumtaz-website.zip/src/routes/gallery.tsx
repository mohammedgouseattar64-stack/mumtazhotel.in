import { createFileRoute } from "@tanstack/react-router";

import { GalleryGrid } from "@/components/site/GalleryGrid";
import { FinalCta, SectionHeading } from "@/components/site/Sections";

export const Route = createFileRoute("/gallery")({
  head: () => ({
    meta: [
      { title: "Gallery | Mumtaz Family Restaurant, Yellapur" },
      {
        name: "description",
        content:
          "Photos of food and dining at Mumtaz Family Restaurant in Yellapur, Karnataka — kebabs, biryani, thalis, curries and more.",
      },
      { property: "og:title", content: "Gallery | Mumtaz Family Restaurant, Yellapur" },
      {
        property: "og:description",
        content: "Food and restaurant photos from Mumtaz Family Restaurant, Yellapur.",
      },
      { property: "og:url", content: "/gallery" },
    ],
    links: [{ rel: "canonical", href: "/gallery" }],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  return (
    <>
      <section className="border-b border-border bg-secondary pt-32 pb-16 lg:pt-40 lg:pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            as="h1"
            eyebrow="Gallery"
            title="Inside Mumtaz"
            description="Dishes and plates from the Mumtaz kitchen in Yellapur. Tap any photo to view it larger."
          />
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
        <GalleryGrid />
      </section>

      <FinalCta />
    </>
  );
}
