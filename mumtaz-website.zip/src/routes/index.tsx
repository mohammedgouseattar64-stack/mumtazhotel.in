import { Link, createFileRoute } from "@tanstack/react-router";
import { MapPin, Star } from "lucide-react";

import { MenuCard } from "@/components/site/MenuCard";
import { OpeningHoursPanel } from "@/components/site/OpeningHoursPanel";
import { Reveal } from "@/components/site/Reveal";
import {
  FinalCta,
  LocationSection,
  QuickActions,
  RatingPanel,
  SectionHeading,
} from "@/components/site/Sections";
import { cuisineCategories, images, menuItems, restaurant } from "@/data/restaurant";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mumtaz Family Restaurant Yellapur | Seafood, Kebabs & Indian Cuisine" },
      {
        name: "description",
        content:
          "Visit Mumtaz Family Restaurant in Yellapur, Karnataka for seafood, kebabs, traditional Indian dishes and Chinese food. View the menu, location, hours and contact details.",
      },
      {
        property: "og:title",
        content: "Mumtaz Family Restaurant Yellapur | Seafood, Kebabs & Indian Cuisine",
      },
      {
        property: "og:description",
        content:
          "A welcoming family restaurant in Yellapur serving seafood, kebabs, traditional Indian favourites and Chinese cuisine.",
      },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Home,
});

function Home() {
  const featured = menuItems.filter((item) => item.featured);

  return (
    <>
      <section className="relative isolate flex min-h-[100svh] items-center overflow-hidden">
        <img
          src={images.kebabPlatter}
          alt="Freshly grilled kebab platter served at Mumtaz Family Restaurant in Yellapur"
          className="absolute inset-0 -z-10 h-full w-full object-cover object-[center_32%]"
        />
        <div className="absolute inset-0 -z-10 bg-charcoal/75" />
        <div className="mx-auto w-full max-w-7xl px-4 pt-28 pb-20 text-charcoal-foreground sm:px-6 lg:pt-32">
          <div className="max-w-3xl">
            <span className="hairline-gold inline-flex border px-3 py-1.5 text-[0.7rem] tracking-[0.2em] uppercase">
              {restaurant.category} • {restaurant.city}
            </span>
            <p className="mt-8 font-display text-4xl tracking-[0.3em] text-gold sm:text-5xl">
              MUMTAZ
            </p>
            <p className="mt-2 text-xl text-charcoal-foreground/85">{restaurant.nameKannada}</p>
            <h1 className="mt-6 text-4xl leading-[1.08] sm:text-6xl lg:text-7xl">
              Authentic Flavours.
              <br />
              Warm Hospitality.
            </h1>
            <p className="mt-6 max-w-2xl text-base leading-relaxed text-charcoal-foreground/85 sm:text-lg">
              Welcome to Mumtaz Family Restaurant, Yellapur — serving delicious seafood, kebabs,
              traditional Indian favourites and Chinese cuisine for families and food lovers.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link
                to="/menu"
                className="bg-gold px-7 py-3.5 text-center text-sm font-semibold tracking-wide text-charcoal transition-opacity hover:opacity-90"
              >
                Explore Menu
              </Link>
              <a
                href={restaurant.mapsDirections}
                target="_blank"
                rel="noreferrer"
                className="hairline-gold inline-flex items-center justify-center gap-2 border px-7 py-3.5 text-sm font-semibold tracking-wide transition-colors hover:bg-charcoal-foreground/10"
              >
                <MapPin className="size-4" aria-hidden="true" />
                Get Directions
              </a>
            </div>
            <dl className="mt-12 flex flex-wrap items-center gap-x-10 gap-y-4 text-sm">
              <div className="flex items-center gap-2">
                <Star className="size-4 fill-gold text-gold" aria-hidden="true" />
                <dt className="sr-only">Rating</dt>
                <dd className="font-semibold">{restaurant.rating} / 5</dd>
              </div>
              <div>
                <dt className="sr-only">Reviews</dt>
                <dd className="text-charcoal-foreground/80">
                  {restaurant.reviewCount.toLocaleString("en-IN")} Reviews
                </dd>
              </div>
              <div>
                <dt className="sr-only">Price range</dt>
                <dd className="text-charcoal-foreground/80">{restaurant.priceRange}</dd>
              </div>
            </dl>
          </div>
        </div>
      </section>

      <QuickActions />

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-28">
        <div className="grid gap-12 lg:grid-cols-2 lg:items-center lg:gap-16">
          <Reveal>
            <SectionHeading
              eyebrow="About Mumtaz"
              title="A Place for Good Food & Good Company"
              description={restaurant.description}
            />
            <p className="mt-5 max-w-2xl text-base leading-relaxed text-muted-foreground">
              Whether it is a family dinner after a drive along NH67 or a quick plate of kebabs on
              the way through Yellapur, the kitchen serves food meant to be shared around one table.
            </p>
            <dl className="mt-10 grid gap-x-8 gap-y-6 sm:grid-cols-2">
              {[
                { term: "Category", detail: restaurant.category },
                { term: "Location", detail: restaurant.city },
                { term: "Services", detail: restaurant.services.join(" • ") },
                { term: "Price", detail: restaurant.priceRange },
              ].map((row) => (
                <div key={row.term} className="border-l-2 border-gold pl-4">
                  <dt className="eyebrow">{row.term}</dt>
                  <dd className="mt-1.5 text-base">{row.detail}</dd>
                </div>
              ))}
            </dl>
            <Link
              to="/about"
              className="mt-10 inline-flex bg-primary px-6 py-3 text-sm font-semibold tracking-wide text-primary-foreground transition-opacity hover:opacity-90"
            >
              Learn About Mumtaz
            </Link>
          </Reveal>
          <Reveal delay={100} className="zoom-media border border-border">
            <img
              src={images.thali}
              alt="Traditional Indian meal thali with rice, roti, curry and sides at Mumtaz, Yellapur"
              loading="lazy"
              decoding="async"
              className="aspect-[4/5] w-full object-cover"
            />
          </Reveal>
        </div>
      </section>

      <section className="bg-secondary py-20 lg:py-28">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Reveal>
            <SectionHeading
              eyebrow="Our Cuisine"
              title="Flavours for Every Table"
              description="Seafood, kebabs, traditional Indian dishes and Chinese food, prepared fresh for families and food lovers."
            />
          </Reveal>
          <div className="mt-12 hidden gap-6 lg:grid lg:grid-cols-3">
            {cuisineCategories.map((cuisine, index) => (
              <Reveal
                key={cuisine.title}
                delay={index * 80}
                className={
                  index === 0
                    ? "zoom-media relative isolate lg:col-span-2 lg:row-span-2"
                    : "zoom-media relative isolate"
                }
              >
                <img
                  src={cuisine.image}
                  alt={cuisine.alt}
                  loading="lazy"
                  decoding="async"
                  className={
                    index === 0
                      ? "h-full min-h-[24rem] w-full object-cover"
                      : "h-full min-h-[15rem] w-full object-cover"
                  }
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/85 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-6 text-charcoal-foreground">
                  <h3 className="font-display text-2xl">{cuisine.title}</h3>
                  <p className="mt-1.5 text-sm text-charcoal-foreground/80">
                    {cuisine.description}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>
          <div className="no-scrollbar mt-10 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 lg:hidden">
            {cuisineCategories.map((cuisine) => (
              <article
                key={cuisine.title}
                className="relative isolate w-[80vw] shrink-0 snap-center sm:w-[45vw]"
              >
                <img
                  src={cuisine.image}
                  alt={cuisine.alt}
                  loading="lazy"
                  decoding="async"
                  className="aspect-[3/4] w-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/85 to-transparent" />
                <div className="absolute inset-x-0 bottom-0 p-5 text-charcoal-foreground">
                  <h3 className="font-display text-xl">{cuisine.title}</h3>
                  <p className="mt-1 text-sm text-charcoal-foreground/80">{cuisine.description}</p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6 lg:py-28">
        <Reveal>
          <SectionHeading
            eyebrow="Menu Preview"
            title="Explore Our Menu"
            description="Starters, kebabs, seafood, biryani, Indian main courses, Chinese dishes, vegetarian plates, beverages and desserts."
          />
        </Reveal>
        <p className="mt-6 max-w-2xl text-sm text-muted-foreground">
          Dish names, descriptions and prices below are editable placeholders until the restaurant
          confirms its full menu.
        </p>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((item, index) => (
            <Reveal key={item.id} delay={index * 60}>
              <MenuCard item={item} />
            </Reveal>
          ))}
        </div>
        <div className="mt-12">
          <Link
            to="/menu"
            className="inline-flex bg-primary px-7 py-3.5 text-sm font-semibold tracking-wide text-primary-foreground transition-opacity hover:opacity-90"
          >
            View Full Menu
          </Link>
        </div>
      </section>

      <section className="bg-secondary py-20 lg:py-28">
        <div className="mx-auto grid max-w-7xl gap-10 px-4 sm:px-6 lg:grid-cols-2 lg:items-start">
          <Reveal>
            <SectionHeading
              eyebrow="Reviews"
              title="What Guests Rate Us"
              description="Mumtaz Family Restaurant holds a 3.9 out of 5 rating across 2,524 reviews. Read them on Google Maps."
            />
            <div className="mt-10">
              <OpeningHoursPanel />
            </div>
          </Reveal>
          <Reveal delay={100}>
            <RatingPanel />
          </Reveal>
        </div>
      </section>

      <LocationSection />
      <FinalCta />
    </>
  );
}
