import { createFileRoute } from "@tanstack/react-router";

import { MenuBrowser } from "@/components/site/MenuBrowser";
import { MenuCard } from "@/components/site/MenuCard";
import { Reveal } from "@/components/site/Reveal";
import { FinalCta, SectionHeading } from "@/components/site/Sections";
import { menuItems, restaurant } from "@/data/restaurant";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu | Mumtaz Family Restaurant, Yellapur" },
      {
        name: "description",
        content:
          "Browse the Mumtaz Family Restaurant menu in Yellapur: starters, kebabs, seafood, chicken, mutton, biryani, Indian main courses, Chinese, vegetarian, beverages and desserts.",
      },
      { property: "og:title", content: "Menu | Mumtaz Family Restaurant, Yellapur" },
      {
        property: "og:description",
        content:
          "Starters, kebabs, seafood, biryani, Indian classics, Chinese and vegetarian dishes at Mumtaz, Yellapur.",
      },
      { property: "og:url", content: "/menu" },
    ],
    links: [{ rel: "canonical", href: "/menu" }],
  }),
  component: MenuPage,
});

function MenuPage() {
  const favourites = menuItems.filter((item) => item.featured);

  return (
    <>
      <section className="border-b border-border bg-secondary pt-32 pb-16 lg:pt-40 lg:pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            as="h1"
            eyebrow="Our Menu"
            title="Explore Our Menu"
            description={`Seafood, kebabs, Indian classics and Chinese dishes. ${restaurant.priceRange}.`}
          />
          <p className="mt-6 max-w-2xl text-sm text-muted-foreground">
            Dish names, descriptions and prices on this page are editable placeholders. Replace them
            with the confirmed Mumtaz menu.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:py-20">
        <MenuBrowser />
      </section>

      <section className="bg-secondary py-20 lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <Reveal>
            <SectionHeading
              eyebrow="Highlights"
              title="Mumtaz Favourites"
              description="A shortlist the restaurant can curate — currently placeholder entries."
            />
          </Reveal>
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {favourites.map((item, index) => (
              <Reveal key={item.id} delay={index * 60}>
                <MenuCard item={item} />
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <FinalCta />
    </>
  );
}
