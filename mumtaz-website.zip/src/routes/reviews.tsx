import { createFileRoute } from "@tanstack/react-router";

import { OpeningHoursPanel } from "@/components/site/OpeningHoursPanel";
import { Reveal } from "@/components/site/Reveal";
import { FinalCta, RatingPanel, SectionHeading } from "@/components/site/Sections";
import { restaurant } from "@/data/restaurant";

export const Route = createFileRoute("/reviews")({
  head: () => ({
    meta: [
      { title: "Reviews | Mumtaz Family Restaurant, Yellapur" },
      {
        name: "description",
        content:
          "Mumtaz Family Restaurant in Yellapur is rated 3.9 out of 5 from 2,524 reviews. Read the reviews and plan your visit.",
      },
      { property: "og:title", content: "Reviews | Mumtaz Family Restaurant, Yellapur" },
      {
        property: "og:description",
        content: "Rated 3.9 out of 5 from 2,524 reviews in Yellapur, Karnataka.",
      },
      { property: "og:url", content: "/reviews" },
    ],
    links: [{ rel: "canonical", href: "/reviews" }],
  }),
  component: ReviewsPage,
});

function ReviewsPage() {
  return (
    <>
      <section className="border-b border-border bg-secondary pt-32 pb-16 lg:pt-40 lg:pb-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6">
          <SectionHeading
            as="h1"
            eyebrow="Reviews"
            title="Rated by Our Guests"
            description={`${restaurant.fullName} holds a ${restaurant.rating} out of 5 rating across ${restaurant.reviewCount.toLocaleString("en-IN")} reviews.`}
          />
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-20 sm:px-6 lg:grid-cols-2 lg:items-start lg:py-28">
        <Reveal>
          <RatingPanel />
        </Reveal>
        <Reveal delay={100}>
          <h2 className="text-3xl leading-tight sm:text-4xl">Read the reviews yourself</h2>
          <p className="mt-5 text-base leading-relaxed text-muted-foreground">
            Individual guest reviews are published on Google Maps, not reproduced here. Use the
            button on the rating panel to open the full list.
          </p>
          <div className="mt-10">
            <OpeningHoursPanel />
          </div>
        </Reveal>
      </section>

      <FinalCta />
    </>
  );
}
